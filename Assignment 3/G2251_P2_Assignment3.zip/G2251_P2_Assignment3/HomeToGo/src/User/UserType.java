package User;

public enum UserType {
	HOST, GUEST, BOTH;

}
